// roles.js - Control de interfaz según rol

function setupRoleBasedUI(userRole) {
  // Esperar a que el DOM esté completamente cargado
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setupRoleBasedUI(userRole));
    return;
  }
  
  console.log('Configurando UI para rol:', userRole);
  
  // SOCIO → Solo lectura
  if (userRole === 'socio') {
    const inputs = document.querySelectorAll('input, select, textarea, button');
    inputs.forEach(input => {
      if (!input.classList.contains('navigation-button') &&
          !input.classList.contains('logout-button') &&
          !input.textContent.includes('Salir') &&
          !input.onclick?.toString().includes('logout')) {
        input.disabled = true;
        input.style.opacity = '0.6';
        input.style.cursor = 'not-allowed';
      }
    });

    const readOnlyMessage = document.createElement('div');
    readOnlyMessage.innerHTML = `
      <div style="background: linear-gradient(135deg, #0ea5e9, #0284c7);
                  color: white; padding: 10px; text-align: center;
                  border-radius: 8px; margin: 10px 0;">
        <i class="fas fa-eye"></i> Modo Solo Lectura - Usuario Socio
      </div>
    `;
    const container = document.querySelector('.container') || document.body;
    container.insertBefore(readOnlyMessage, container.firstChild);
  }

  // VENDEDOR → Ocultar elementos que no son capturador o calendario
  if (userRole.startsWith('vendedor')) {
    const dashboardLinks = document.querySelectorAll('.dashboard-only');
    console.log('Ocultando Dashboard para vendedor:', dashboardLinks.length, 'elementos encontrados');
    dashboardLinks.forEach(el => el.style.display = 'none');
    
    // NUEVO: Ocultar específicamente enlaces y botones del dashboard
    const dashboardNavButtons = document.querySelectorAll('a[href="dashboard.html"], .nav-btn[href="dashboard.html"]');
    dashboardNavButtons.forEach(button => {
      button.style.display = 'none';
    });
    
    // NUEVO: Ocultar botones que contienen texto "Dashboard"
    const allButtons = document.querySelectorAll('button, a');
    allButtons.forEach(button => {
      if (button.textContent.includes('Dashboard') || button.textContent.includes('Ver Dashboard')) {
        button.style.display = 'none';
      }
    });
    
    console.log('Elementos de dashboard ocultados para vendedor');
  }

  // Si NO es admin → ocultar elementos marcados como admin-only
  if (userRole !== 'admin') {
    const adminElements = document.querySelectorAll('.admin-only');
    console.log('Ocultando elementos admin-only:', adminElements.length, 'elementos encontrados');
    adminElements.forEach(el => { el.style.display = 'none'; });
  }
  
  console.log('Configuración de UI completada para rol:', userRole);
}

window.setupRoleBasedUI = setupRoleBasedUI;