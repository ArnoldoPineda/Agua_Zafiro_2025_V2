// 🔑 CONFIGURACIÓN DE SUPABASE - AGUA ZAFIRO (VERSIÓN MEJORADA CON SEGURIDAD)
// Conecta el frontend con la base de datos Supabase

const SUPABASE_URL = 'https://hjrplwxvyukevcljodyg.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhqcnBsd3h2eXVrZXZjbGpvZHlnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTgwMzUzMzQsImV4cCI6MjA3MzYxMTMzNH0.uJ-krjLrFVo7cHuIQQb1-x2wQzXwyZfcvg4XvnppkqE';

// 📡 INICIALIZAR CLIENTE SUPABASE
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// 🔐 FUNCIONES DE AUTENTICACIÓN MEJORADAS
const SupabaseAuth = {
    // Generar ID de sesión único
    generateSessionId() {
        return 'sess_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now().toString(36);
    },

    // Verificar si la sesión es válida (no expirada)
    isSessionValid() {
        const user = localStorage.getItem('currentUser');
        const lastActivity = localStorage.getItem('lastActivity');
        
        if (!user || !lastActivity) return false;
        
        const lastTime = new Date(lastActivity);
        const now = new Date();
        const diffHours = (now - lastTime) / (1000 * 60 * 60);
        
        // Sesión expira después de 8 horas de inactividad
        if (diffHours > 8) {
            console.log('🕒 Sesión expirada por inactividad');
            this.logout();
            return false;
        }
        
        return true;
    },

    // Login mejorado con validaciones de seguridad
    async login(username, password) {
        try {
            console.log(`🔐 Intentando login para: ${username}`);

            // Validaciones básicas
            if (!username || !password) {
                return { success: false, error: 'Usuario y contraseña son requeridos' };
            }

            if (username.length < 3) {
                return { success: false, error: 'Usuario debe tener al menos 3 caracteres' };
            }

            // Buscar usuario por username solamente (sin password en la query por seguridad)
            const { data: users, error } = await supabaseClient
                .from('users')
                .select('*')
                .eq('username', username)
                .eq('is_active', true)
                .single();

            if (error || !users) {
                // Simular tiempo de respuesta para evitar timing attacks
                await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 500));
                return { success: false, error: 'Usuario o contraseña incorrectos' };
            }

            // Verificar contraseña (usando el método actual por compatibilidad)
            const expectedHash = `$2a$10$example_${username}_hash`;
            if (users.password_hash !== expectedHash) {
                // Simular tiempo de respuesta consistente
                await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 500));
                return { success: false, error: 'Usuario o contraseña incorrectos' };
            }

            // Verificar que el usuario esté activo
            if (!users.is_active) {
                return { success: false, error: 'Cuenta desactivada. Contacte al administrador.' };
            }

            // Crear sesión segura
            const sessionData = {
                id: users.id,
                username: users.username,
                role: users.role,
                full_name: users.full_name,
                loginTime: new Date().toISOString(),
                sessionId: this.generateSessionId(),
                // NO incluir información sensible aquí
            };

            // Guardar sesión y actualizar actividad
            localStorage.setItem('currentUser', JSON.stringify(sessionData));
            localStorage.setItem('lastActivity', new Date().toISOString());

            console.log(`✅ Login exitoso para: ${username} (${users.role})`);
            
            return { success: true, user: sessionData };
            
        } catch (error) {
            console.error('❌ Error en login:', error);
            // No revelar detalles técnicos al usuario
            return { success: false, error: 'Error de conexión. Intente nuevamente.' };
        }
    },

    // Obtener usuario actual con validaciones de seguridad
    getCurrentUser() {
        // Verificar validez de sesión primero
        if (!this.isSessionValid()) {
            return null;
        }
        
        const user = localStorage.getItem('currentUser');
        if (!user) return null;
        
        try {
            const userData = JSON.parse(user);
            
            // Actualizar última actividad
            localStorage.setItem('lastActivity', new Date().toISOString());
            
            // Validar estructura básica del objeto usuario
            if (!userData.id || !userData.username || !userData.role) {
                console.error('❌ Datos de usuario corruptos');
                this.logout();
                return null;
            }
            
            return userData;
        } catch (error) {
            console.error('❌ Error parsing user data:', error);
            this.logout();
            return null;
        }
    },

    // Logout mejorado con limpieza completa
    logout() {
        try {
            const currentUser = this.getCurrentUser();
            if (currentUser) {
                console.log(`🚪 Logout: ${currentUser.username}`);
            }
            
            // Limpiar datos de sesión
            localStorage.removeItem('currentUser');
            localStorage.removeItem('lastActivity');
            
            // Limpiar cualquier dato temporal o caché
            const keysToRemove = [];
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key && (key.startsWith('temp_') || 
                           key.startsWith('cache_') || 
                           key.startsWith('draft_') ||
                           key.startsWith('borrador_'))) {
                    keysToRemove.push(key);
                }
            }
            keysToRemove.forEach(key => localStorage.removeItem(key));
            
            return { success: true };
        } catch (error) {
            console.error('❌ Error en logout:', error);
            return { success: false, error: error.message };
        }
    },

    // Verificar si está logueado con validación de sesión
    isLoggedIn() {
        return this.getCurrentUser() !== null;
    },

    // Sistema de permisos mejorado
    hasPermission(action, resource = null) {
        const user = this.getCurrentUser();
        if (!user) return false;
        
        const permissions = {
            'admin': {
                'create': true,
                'read': true,
                'update': true,
                'delete': true,
                'export': true,
                'manage_users': true
            },
            'socio': {
                'create': false,
                'read': true,
                'update': false,
                'delete': false,
                'export': true,
                'manage_users': false
            },
            'vendedor': {
                'create': true,
                'read': true,
                'update': false, // Solo pueden actualizar sus propios registros
                'delete': false,
                'export': false,
                'manage_users': false
            }
        };
        
        const userPermissions = permissions[user.role];
        if (!userPermissions) {
            console.warn(`⚠️ Rol desconocido: ${user.role}`);
            return false;
        }
        
        return userPermissions[action] === true;
    },

    // Verificar si puede acceder a un recurso específico
    canAccessResource(resourceType, resourceData = null) {
        const user = this.getCurrentUser();
        if (!user) return false;

        // Administradores pueden acceder a todo
        if (user.role === 'admin') return true;

        // Socios pueden ver todo pero no modificar
        if (user.role === 'socio') {
            return resourceType === 'view' || resourceType === 'read';
        }

        // Vendedores solo pueden ver/modificar sus propios registros
        if (user.role === 'vendedor') {
            if (resourceData && resourceData.created_by) {
                return resourceData.created_by === user.id;
            }
            // Si no hay información del propietario, permitir acceso básico
            return resourceType === 'create' || resourceType === 'read';
        }

        return false;
    }
};

// 📊 FUNCIONES DE DATOS (manteniendo compatibilidad)
const SupabaseData = {
    // Obtener catálogos con caché temporal
    async getCatalogs(tipo) {
        try {
            const cacheKey = `catalogs_${tipo}`;
            const cached = localStorage.getItem(cacheKey);
            const cacheTime = localStorage.getItem(`${cacheKey}_time`);
            
            // Usar caché si es menor a 1 hora
            if (cached && cacheTime) {
                const age = Date.now() - parseInt(cacheTime);
                if (age < 60 * 60 * 1000) { // 1 hora
                    console.log(`📋 Usando caché para ${tipo}`);
                    return { success: true, data: JSON.parse(cached) };
                }
            }

            const { data, error } = await supabaseClient
                .from('catalogs')
                .select('*')
                .eq('tipo', tipo)
                .eq('is_active', true)
                .order('orden');

            if (error) throw error;
            
            // Guardar en caché
            localStorage.setItem(cacheKey, JSON.stringify(data));
            localStorage.setItem(`${cacheKey}_time`, Date.now().toString());
            
            return { success: true, data };
        } catch (error) {
            console.error(`❌ Error obteniendo catálogo ${tipo}:`, error);
            return { success: false, error: error.message };
        }
    },

    // FUNCIÓN CORREGIDA: Guardar registro con validación de permisos
    async saveRegistroDiario(fecha, data) {
        try {
            const currentUser = SupabaseAuth.getCurrentUser();
            if (!currentUser) {
                throw new Error('Usuario no autenticado');
            }

            // Verificar permisos
            if (!SupabaseAuth.hasPermission('create')) {
                throw new Error('No tiene permisos para crear registros');
            }

            console.log(`💾 Guardando registro para ${fecha} por ${currentUser.username}`);

            // Validar datos básicos
            if (!fecha || !data) {
                throw new Error('Fecha y datos son requeridos');
            }

            // === LÓGICA CORREGIDA PARA EVITAR DUPLICATE KEY ERROR ===
            
            // 1. Verificar si ya existe un registro para esta fecha
const { data: existingRecord, error: searchError } = await supabaseClient
    .from('daily_records')
    .select('id')
    .eq('fecha', fecha)
    .maybeSingle(); // CAMBIO: usar maybeSingle() en lugar de single()

            let dailyRecord;

            if (existingRecord) {
                // ACTUALIZAR registro existente
                console.log(`📝 Actualizando registro existente con ID: ${existingRecord.id}`);
                
                const { data: updatedRecord, error: updateError } = await supabaseClient
                    .from('daily_records')
                    .update({
                        caja_inicial: parseFloat(data.cajaInicial || 0),
                        observaciones: data.observaciones || '',
                        updated_at: new Date().toISOString()
                    })
                    .eq('id', existingRecord.id)
                    .select()
                    .single();

                if (updateError) throw new Error(`Error actualizando registro: ${updateError.message}`);
                dailyRecord = updatedRecord;

            } else {
                // CREAR nuevo registro
                console.log(`➕ Creando nuevo registro para fecha: ${fecha}`);
                
                const { data: newRecord, error: createError } = await supabaseClient
                    .from('daily_records')
                    .insert({
                        fecha: fecha,
                        caja_inicial: parseFloat(data.cajaInicial || 0),
                        observaciones: data.observaciones || '',
                        created_by: currentUser.id,
                        created_at: new Date().toISOString(),
                        updated_at: new Date().toISOString()
                    })
                    .select()
                    .single();

                if (createError) throw new Error(`Error creando registro: ${createError.message}`);
                dailyRecord = newRecord;
            }

            // 2. Limpiar datos existentes del día (para ambos casos)
            await Promise.all([
                supabaseClient.from('sales').delete().eq('daily_record_id', dailyRecord.id),
                supabaseClient.from('expenses').delete().eq('daily_record_id', dailyRecord.id),
                supabaseClient.from('credits').delete().eq('daily_record_id', dailyRecord.id)
            ]);

            // 3. Insertar nuevos datos
            const insertPromises = [];

            if (data.ventas && data.ventas.length > 0) {
                const ventasToInsert = data.ventas.map((venta, index) => ({
                    daily_record_id: dailyRecord.id,
                    vendedor: venta.vendedor,
                    ciudad: venta.ciudad,
                    producto: venta.producto,
                    cantidad: parseInt(venta.cantidad) || 0,
                    precio: parseFloat(venta.precio) || 0,
                    total: parseFloat(venta.total) || 0,
                    orden: index + 1
                }));

                insertPromises.push(
                    supabaseClient.from('sales').insert(ventasToInsert)
                );
            }

            if (data.gastos && data.gastos.length > 0) {
                const gastosToInsert = data.gastos.map((gasto, index) => ({
                    daily_record_id: dailyRecord.id,
                    categoria: gasto.categoria,
                    descripcion: gasto.descripcion || '',
                    monto: parseFloat(gasto.monto) || 0,
                    orden: index + 1
                }));

                insertPromises.push(
                    supabaseClient.from('expenses').insert(gastosToInsert)
                );
            }

            if (data.creditos && data.creditos.length > 0) {
                const creditosToInsert = data.creditos.map((credito, index) => ({
                    daily_record_id: dailyRecord.id,
                    categoria: credito.categoria,
                    detalle: credito.detalle || '',
                    monto: parseFloat(credito.monto) || 0,
                    orden: index + 1
                }));

                insertPromises.push(
                    supabaseClient.from('credits').insert(creditosToInsert)
                );
            }

            // Ejecutar todas las inserciones
            const results = await Promise.all(insertPromises);
            
            // Verificar errores en las inserciones
            for (const result of results) {
                if (result.error) throw result.error;
            }

            // Limpiar caché relacionado
            this.clearDashboardCache();

            console.log(`✅ Registro guardado exitosamente para ${fecha}`);
            return { success: true, data: dailyRecord };

        } catch (error) {
            console.error('❌ Error guardando registro:', error);
            return { success: false, error: error.message };
        }
    },

    // Limpiar caché del dashboard
    clearDashboardCache() {
        const cacheKeys = ['dashboard_data', 'dashboard_data_time'];
        cacheKeys.forEach(key => localStorage.removeItem(key));
    },

    // Las demás funciones permanecen iguales...
    async getRegistroDiario(fecha) {
        try {
            const { data: dailyRecord, error: dailyError } = await supabaseClient
                .from('daily_records')
                .select('*')
                .eq('fecha', fecha)
                .single();

            if (dailyError && dailyError.code !== 'PGRST116') throw dailyError;
            if (!dailyRecord) return { success: true, data: null };

            const [ventas, gastos, creditos] = await Promise.all([
                supabaseClient.from('sales').select('*').eq('daily_record_id', dailyRecord.id).order('orden'),
                supabaseClient.from('expenses').select('*').eq('daily_record_id', dailyRecord.id).order('orden'),
                supabaseClient.from('credits').select('*').eq('daily_record_id', dailyRecord.id).order('orden')
            ]);

            return {
                success: true,
                data: {
                    id: dailyRecord.id,
                    fecha: dailyRecord.fecha,
                    cajaInicial: dailyRecord.caja_inicial,
                    observaciones: dailyRecord.observaciones,
                    ventas: ventas.data || [],
                    gastos: gastos.data || [],
                    creditos: creditos.data || []
                }
            };
        } catch (error) {
            console.error('❌ Error obteniendo registro:', error);
            return { success: false, error: error.message };
        }
    },

    async getDashboardData() {
        try {
            const fechaInicio = new Date();
            fechaInicio.setDate(fechaInicio.getDate() - 30);
            const fechaInicioStr = fechaInicio.toISOString().split('T')[0];

            const { data: records, error } = await supabaseClient
                .from('daily_records')
                .select(`
                    fecha,
                    caja_inicial,
                    sales(vendedor, ciudad, producto, cantidad, precio, total),
                    expenses(categoria, monto),
                    credits(categoria, monto)
                `)
                .gte('fecha', fechaInicioStr)
                .order('fecha', { ascending: false });

            if (error) throw error;
            return { success: true, data: records || [] };
        } catch (error) {
            console.error('❌ Error obteniendo datos dashboard:', error);
            return { success: false, error: error.message };
        }
    }
};

// 🌐 HACER DISPONIBLE GLOBALMENTE
window.SupabaseAuth = SupabaseAuth;
window.SupabaseData = SupabaseData;
window.supabase = supabaseClient;

console.log('🔒 Supabase con mejoras de seguridad cargado correctamente para Agua Zafiro');